# Amdahl Reality Gap — Lab 1

Student: Shakirov Serik  
Student ID: 230103112

## Confirmed workload

The worksheet defines:

N = 10,000,000 + (last 4 digits of Student ID × 1,000)

Last four digits = 3112

Therefore:

N = 13,112,000

## Confirmed hardware

From the supplied results:

- CPU: Intel(R) Core(TM) i7-1065G7 CPU @ 1.30GHz
- Physical cores: 4
- Logical processors: 8

## Confirmed sequential results

The supplied document contains:

- Run 1 = 3.98 s
- Run 2 = 4.02 s
- Run 3 = 4.03 s
- T_seq = (4.02 + 4.03) / 2 = 4.025 s
- Maximum stopping time = 688
- Checksum = 72,240,359

Run 1 is correctly treated as the cold run and is not included in T_seq.

## Missing empirical measurements

The uploaded results do NOT contain the required parallel Run 1/Run 2/Run 3 values, S_emp, p, S_theo, Reality Gap, false-sharing timings, or scheduling timings.

Those values must come from actual execution on the machine. They are intentionally left blank in `results.csv`; inventing hardware-specific timings would make the submission inconsistent with the lab's stated requirement for real physical execution.

## Files

- `hw_info.txt` — confirmed hardware information
- `collatz.c` — C/OpenMP program for the required experiments
- `results.csv` — results table, with supplied real values filled in
- `make_plot.py` — creates `speedup_plot.png` after parallel results are entered

## Compile on Windows

Using MinGW/GCC with OpenMP:

```text
gcc -O2 -fopenmp collatz.c -o collatz.exe
collatz.exe
```

If your GCC command is available in Command Prompt, this should run the benchmark.

## Amdahl calculation

Once the real 2-thread empirical speedup is known:

p = 2 × (1 - 1/S_emp(2))

Then for each k:

S_theo(k) = 1 / ((1-p) + p/k)

Reality Gap:

Delta(k) = S_theo(k) - S_emp(k)

## Important

Do not replace the blank parallel/false-sharing/scheduling values with guessed numbers. The baseline values above are the only machine measurements supplied in the uploaded document.
