import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("results.csv")
p = None
s2 = df.loc[(df["experiment"] == "Parallel") & (df["threads"] == 2), "S_emp"]

if len(s2) and pd.notna(s2.iloc[0]):
    s2 = float(s2.iloc[0])
    p = 2 * (1 - 1 / s2)
    df.loc[df["threads"] >= 1, "S_theo"] = 1 / ((1-p) + p / df["threads"])
    df["delta"] = df["S_theo"] - df["S_emp"]

plt.figure(figsize=(8,5))
plt.plot(df["threads"], df["S_emp"], marker="o", label="Empirical")
if df["S_theo"].notna().any():
    plt.plot(df["threads"], df["S_theo"], marker="o", label="Amdahl theoretical")
plt.plot(df["threads"], df["threads"], marker="o", label="Linear ideal")
plt.xlabel("Threads")
plt.ylabel("Speedup")
plt.title("Amdahl Reality Gap")
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("speedup_plot.png", dpi=200)
print("Saved speedup_plot.png")
