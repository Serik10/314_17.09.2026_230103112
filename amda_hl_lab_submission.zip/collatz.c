#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

#define N 13112000LL
#define MOD 1000000007ULL

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1ULL) == 0)
            n >>= 1;
        else
            n = 3 * n + 1;
        steps++;
    }
    return steps;
}

static void sequential_run(void) {
    uint32_t max_steps = 0;
    uint64_t checksum = 0;

    double start = omp_get_wtime();

    for (uint64_t i = 1; i <= N; i++) {
        uint32_t s = collatz_steps(i);
        if (s > max_steps) max_steps = s;
        checksum = (checksum + s) % MOD;
    }

    double elapsed = omp_get_wtime() - start;

    printf("Sequential\n");
    printf("N: %lld\n", (long long)N);
    printf("Time: %.6f seconds\n", elapsed);
    printf("Maximum stopping time: %u\n", max_steps);
    printf("Checksum: %llu\n", (unsigned long long)checksum);
}

static void parallel_run(int threads) {
    uint32_t max_steps = 0;
    uint64_t checksum = 0;

    omp_set_num_threads(threads);
    double start = omp_get_wtime();

    #pragma omp parallel for reduction(max:max_steps) reduction(+:checksum) schedule(static)
    for (long long i = 1; i <= N; i++) {
        uint32_t s = collatz_steps((uint64_t)i);
        if (s > max_steps) max_steps = s;
        checksum += s;
        if (checksum >= MOD) checksum %= MOD;
    }

    checksum %= MOD;
    double elapsed = omp_get_wtime() - start;

    printf("%d threads | %.6f s | max=%u | checksum=%llu\n",
           threads, elapsed, max_steps, (unsigned long long)checksum);
}

static void false_sharing_run(int threads, int padded) {
    int *counts = NULL;
    typedef struct {
        int count;
        char pad[60];
    } Padded;

    Padded *pc = NULL;

    if (padded)
        pc = (Padded*)calloc((size_t)threads, sizeof(Padded));
    else
        counts = (int*)calloc((size_t)threads, sizeof(int));

    omp_set_num_threads(threads);
    double start = omp_get_wtime();

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();

        #pragma omp for schedule(static)
        for (long long i = 1; i <= N; i++) {
            if (collatz_steps((uint64_t)i) > 100) {
                if (padded) pc[tid].count++;
                else counts[tid]++;
            }
        }
    }

    double elapsed = omp_get_wtime() - start;
    long long total = 0;

    for (int i = 0; i < threads; i++)
        total += padded ? pc[i].count : counts[i];

    printf("False sharing | %s | %d threads | %.6f s | hits=%lld\n",
           padded ? "padded" : "per-thread-array",
           threads, elapsed, total);

    free(counts);
    free(pc);
}

static void scheduling_run(int threads, const char *kind) {
    uint64_t checksum = 0;
    uint32_t max_steps = 0;

    omp_set_num_threads(threads);
    double start = omp_get_wtime();

    if (kind[0] == 's') {
        #pragma omp parallel for reduction(+:checksum) reduction(max:max_steps) schedule(static)
        for (long long i = 1; i <= N; i++) {
            uint32_t s = collatz_steps((uint64_t)i);
            checksum += s;
            if (s > max_steps) max_steps = s;
        }
    } else if (kind[0] == '1') {
        #pragma omp parallel for reduction(+:checksum) reduction(max:max_steps) schedule(static,1000)
        for (long long i = 1; i <= N; i++) {
            uint32_t s = collatz_steps((uint64_t)i);
            checksum += s;
            if (s > max_steps) max_steps = s;
        }
    } else if (kind[0] == '2') {
        #pragma omp parallel for reduction(+:checksum) reduction(max:max_steps) schedule(dynamic,100)
        for (long long i = 1; i <= N; i++) {
            uint32_t s = collatz_steps((uint64_t)i);
            checksum += s;
            if (s > max_steps) max_steps = s;
        }
    } else if (kind[0] == '3') {
        #pragma omp parallel for reduction(+:checksum) reduction(max:max_steps) schedule(dynamic,10000)
        for (long long i = 1; i <= N; i++) {
            uint32_t s = collatz_steps((uint64_t)i);
            checksum += s;
            if (s > max_steps) max_steps = s;
        }
    } else {
        #pragma omp parallel for reduction(+:checksum) reduction(max:max_steps) schedule(guided)
        for (long long i = 1; i <= N; i++) {
            uint32_t s = collatz_steps((uint64_t)i);
            checksum += s;
            if (s > max_steps) max_steps = s;
        }
    }

    checksum %= MOD;
    double elapsed = omp_get_wtime() - start;

    printf("Scheduling | %s | %d threads | %.6f s | max=%u | checksum=%llu\n",
           kind, threads, elapsed, max_steps, (unsigned long long)checksum);
}

int main(void) {
    printf("Student: 230103112\n");
    printf("N = %lld\n\n", (long long)N);

    sequential_run();

    printf("\nParallel runs:\n");
    parallel_run(1);
    parallel_run(2);
    parallel_run(4);
    parallel_run(8);

    printf("\nFalse sharing:\n");
    false_sharing_run(8, 0);
    false_sharing_run(8, 1);

    printf("\nScheduling:\n");
    scheduling_run(8, "static");
    scheduling_run(8, "1000");
    scheduling_run(8, "100");
    scheduling_run(8, "10000");
    scheduling_run(8, "guided");

    return 0;
}
