# Parallel Computing Labs 1–3 — Java

Student: Serik Shakirov

## Language

Java was used for all three labs. The implementations use standard Java concurrency features, so no OpenMP installation or Python is required.

---

# Lab 1 — Fork-Join / Threads

## Objective

The purpose of Lab 1 is to create several Java threads, start them concurrently, and wait for all of them to finish.

## Result

Observed output:

```text
Hello from thread 2
Hello from thread 1
Hello from thread 0
Hello from thread 3
All threads finished.
```

The order of the first four lines is not fixed because the operating system/JVM scheduler determines when each thread gets CPU time.

The final line appears after all worker threads because the main thread calls `join()` for every thread.

## Questions

### Why can thread IDs appear in different orders?

Threads execute concurrently, so the exact execution order is controlled by the scheduler. Therefore, thread 2 may print before thread 0, for example.

### What happens when there are too many threads?

Too many threads can increase context switching, scheduling overhead, memory usage, and cache pressure. More threads therefore do not always mean better performance.

### What is a barrier?

A barrier is a synchronization point. Threads wait at the barrier until the required threads reach it, and then they continue.

### Hardware thread vs OS thread

A hardware thread is an execution context provided by the CPU. An OS thread is a software execution unit scheduled by the operating system.

---

# Lab 2 — Pi and Reduction

## Objective

The goal is to approximate Pi using numerical integration and then calculate it in parallel using a reduction approach.

## Sequential result

```text
Pi = 3.1415926535904264
```

The result is very close to the mathematical value of Pi.

## Parallel reduction result

```text
Threads: 4
Pi: 3.1415926535896825
Time: 0.2625815 seconds
```

The sequential and parallel Pi values differ only in the last decimal places because floating-point additions can be performed in a different order.

## Why not use one shared sum?

If multiple threads update the same variable without synchronization, a race condition can occur. One thread can read an old value while another thread is updating it, causing a lost update.

## Reduction

Each worker thread calculates a private `localSum`. After all threads finish, the main thread combines these partial sums into `totalSum`.

This reduces contention during the main calculation.

## Amdahl's Law

If 5% of a program is serial:

```text
P = 0.95
Smax = 1 / (1 - 0.95)
Smax = 20
```

Therefore, the theoretical maximum speedup is 20×.

---

# Lab 3 — Mandelbrot Scheduling

## Objective

The purpose of Lab 3 is to compare different ways of distributing Mandelbrot rows among threads.

The main scheduling approaches are:

- Sequential
- Static
- Dynamic
- Guided

## Provided measured results

The sequential benchmark was run twice:

```text
Sequential time: 1.577605399 seconds
Sequential time: 1.6399902 seconds
```

For calculations below, the first measured sequential run is used as the baseline:

```text
T1 = 1.577605399 seconds
```

The following parallel results were measured:

```text
Static: 0.8729407 seconds
Dynamic: 0.414110701 seconds
```

## Speedup calculations

Formula:

```text
Speedup = Sequential time / Parallel time
```

### Static

```text
Speedup = 1.577605399 / 0.8729407
        ≈ 1.8073
```

### Dynamic

```text
Speedup = 1.577605399 / 0.414110701
        ≈ 3.8098
```

## Results table

| Method | Threads | Time (s) | Speedup |
|---|---:|---:|---:|
| Sequential | 1 | 1.577605399 | 1.000 |
| Static | 4 | 0.8729407 | 1.807 |
| Dynamic | 4 | 0.414110701 | 3.810 |

The two sequential measurements are close but not identical. This is normal for timing experiments because background processes, JVM state, CPU frequency, cache state, and other system activity can affect execution time.

## Static scheduling

Static scheduling divides the work before execution. Each thread receives a fixed group of rows.

Advantage: low scheduling overhead.

Disadvantage: if some rows require more computation than others, some threads can finish earlier and wait for the remaining thread.

## Dynamic scheduling

Dynamic scheduling gives a thread another row/work item after it finishes its current work.

Advantage: it can balance irregular workloads better.

Disadvantage: the shared work counter introduces synchronization overhead.

## Guided scheduling

Guided scheduling starts with larger chunks and gradually reduces the chunk size as the remaining work becomes smaller.

The Lab3.java file contains a simple Java implementation of this idea. The guided result should be measured by running that program on the same machine.

## Why is Mandelbrot useful for scheduling experiments?

Different parts of the Mandelbrot image can require different numbers of iterations. Therefore, the amount of work per row is not perfectly uniform. This makes scheduling and load balancing important.

## Conclusion

Lab 3 shows that scheduling strategy can significantly affect parallel performance. In the measured run, dynamic scheduling was faster than static scheduling for the selected Mandelbrot workload.

This result should be interpreted specifically for this run and hardware rather than as a universal rule for every workload.

---

# Final Summary

Three labs were completed using Java:

1. Lab 1 — Java threads and synchronization with `join()`.
2. Lab 2 — Pi calculation and parallel reduction.
3. Lab 3 — Mandelbrot calculation with static and dynamic scheduling, with a guided implementation included for further measurement.

No Python-specific knowledge is required for these implementations.
