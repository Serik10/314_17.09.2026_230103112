import java.util.concurrent.atomic.AtomicInteger;

public class Lab3 {

    static final int WIDTH = 2000;
    static final int HEIGHT = 2000;
    static final int MAX_ITER = 1000;

    static void calculateRow(int y) {
        double cy = (y - HEIGHT / 2.0) * 4.0 / HEIGHT;

        for (int x = 0; x < WIDTH; x++) {
            double cx = (x - WIDTH / 2.0) * 4.0 / WIDTH;

            double zx = 0.0;
            double zy = 0.0;
            int iter = 0;

            while (zx * zx + zy * zy <= 4.0 && iter < MAX_ITER) {
                double newZx = zx * zx - zy * zy + cx;
                zy = 2.0 * zx * zy + cy;
                zx = newZx;
                iter++;
            }
        }
    }

    static double sequential() {
        long start = System.nanoTime();

        for (int y = 0; y < HEIGHT; y++) {
            calculateRow(y);
        }

        return (System.nanoTime() - start) / 1_000_000_000.0;
    }

    static double runStatic(int numberOfThreads) throws InterruptedException {
        Thread[] threads = new Thread[numberOfThreads];
        int rowsPerThread = HEIGHT / numberOfThreads;

        long start = System.nanoTime();

        for (int t = 0; t < numberOfThreads; t++) {
            final int threadId = t;
            final int startRow = threadId * rowsPerThread;
            final int endRow = (threadId == numberOfThreads - 1)
                    ? HEIGHT
                    : (threadId + 1) * rowsPerThread;

            threads[t] = new Thread(() -> {
                for (int y = startRow; y < endRow; y++) {
                    calculateRow(y);
                }
            });

            threads[t].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        return (System.nanoTime() - start) / 1_000_000_000.0;
    }

    static double runDynamic(int numberOfThreads) throws InterruptedException {
        AtomicInteger nextRow = new AtomicInteger(0);
        Thread[] threads = new Thread[numberOfThreads];

        long start = System.nanoTime();

        for (int t = 0; t < numberOfThreads; t++) {
            threads[t] = new Thread(() -> {
                while (true) {
                    int y = nextRow.getAndIncrement();

                    if (y >= HEIGHT) {
                        break;
                    }

                    calculateRow(y);
                }
            });

            threads[t].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        return (System.nanoTime() - start) / 1_000_000_000.0;
    }

    static double runGuided(int numberOfThreads) throws InterruptedException {
        AtomicInteger nextRow = new AtomicInteger(0);
        Thread[] threads = new Thread[numberOfThreads];

        long start = System.nanoTime();

        for (int t = 0; t < numberOfThreads; t++) {
            threads[t] = new Thread(() -> {
                while (true) {
                    int current = nextRow.get();

                    if (current >= HEIGHT) {
                        break;
                    }

                    int remaining = HEIGHT - current;
                    int chunk = Math.max(1, remaining / (numberOfThreads * 2));

                    if (nextRow.compareAndSet(current, current + chunk)) {
                        int end = Math.min(HEIGHT, current + chunk);

                        for (int y = current; y < end; y++) {
                            calculateRow(y);
                        }
                    }
                }
            });

            threads[t].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        return (System.nanoTime() - start) / 1_000_000_000.0;
    }

    public static void main(String[] args) throws InterruptedException {
        int numberOfThreads = 4;

        double seq = sequential();
        System.out.println("Sequential: " + seq + " seconds");

        double stat = runStatic(numberOfThreads);
        System.out.println("Static (" + numberOfThreads + " threads): "
                + stat + " seconds");

        double dyn = runDynamic(numberOfThreads);
        System.out.println("Dynamic (" + numberOfThreads + " threads): "
                + dyn + " seconds");

        double guided = runGuided(numberOfThreads);
        System.out.println("Guided (" + numberOfThreads + " threads): "
                + guided + " seconds");

        System.out.println();
        System.out.println("Speedup, static: " + seq / stat);
        System.out.println("Speedup, dynamic: " + seq / dyn);
        System.out.println("Speedup, guided: " + seq / guided);
    }
}
