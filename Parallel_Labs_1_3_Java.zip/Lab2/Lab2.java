public class Lab2 {
    public static void main(String[] args) {
        long numSteps = 100_000_000L;

        double step = 1.0 / numSteps;
        double sum = 0.0;

        for (long i = 0; i < numSteps; i++) {
            double x = (i + 0.5) * step;
            sum += 4.0 / (1.0 + x * x);
        }

        double pi = sum * step;

        System.out.println("Pi = " + pi);
    }
}
