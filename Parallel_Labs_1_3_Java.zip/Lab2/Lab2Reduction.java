public class Lab2Reduction {

    static class Worker extends Thread {
        private final long start;
        private final long end;
        private final double step;
        private double localSum = 0.0;

        public Worker(long start, long end, double step) {
            this.start = start;
            this.end = end;
            this.step = step;
        }

        @Override
        public void run() {
            for (long i = start; i < end; i++) {
                double x = (i + 0.5) * step;
                localSum += 4.0 / (1.0 + x * x);
            }
        }

        public double getLocalSum() {
            return localSum;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        long numSteps = 100_000_000L;
        int numberOfThreads = 4;

        double step = 1.0 / numSteps;
        Worker[] workers = new Worker[numberOfThreads];

        long stepsPerThread = numSteps / numberOfThreads;

        long startTime = System.nanoTime();

        for (int i = 0; i < numberOfThreads; i++) {
            long start = i * stepsPerThread;
            long end = (i == numberOfThreads - 1)
                    ? numSteps
                    : (i + 1) * stepsPerThread;

            workers[i] = new Worker(start, end, step);
            workers[i].start();
        }

        double totalSum = 0.0;

        for (Worker worker : workers) {
            worker.join();
            totalSum += worker.getLocalSum();
        }

        double pi = totalSum * step;

        long endTime = System.nanoTime();
        double time = (endTime - startTime) / 1_000_000_000.0;

        System.out.println("Threads: " + numberOfThreads);
        System.out.println("Pi: " + pi);
        System.out.println("Time: " + time + " seconds");
    }
}
