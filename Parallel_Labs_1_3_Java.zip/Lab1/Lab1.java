public class Lab1 {
    public static void main(String[] args) throws InterruptedException {

        int numberOfThreads = 4;
        Thread[] threads = new Thread[numberOfThreads];

        for (int i = 0; i < numberOfThreads; i++) {
            final int threadId = i;

            threads[i] = new Thread(() -> {
                System.out.println("Hello from thread " + threadId);
            });

            threads[i].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        System.out.println("All threads finished.");
    }
}
